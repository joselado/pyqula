f2py2.7 -c -m classicalspinf90 classicalspinf90.f90
cp classicalspinf90.so ../../ # copy to the main directory
