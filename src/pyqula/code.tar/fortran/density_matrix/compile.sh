f2py2.7 -c -m density_matrixf90 density_matrixf90.f90
cp density_matrixf90.so ../../ # copy to the main directory

