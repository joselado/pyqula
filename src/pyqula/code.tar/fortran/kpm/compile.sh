XXX -llapack -c -m kpmf90 kpm.f90
cp kpmf90.so ../../ # copy to the main directory
