XXX -llapack -c -m berry_curvaturef90 berry_curvature.f90
cp berry_curvaturef90.so ../../ # copy to the main directory
