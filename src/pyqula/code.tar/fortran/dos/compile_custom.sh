f2py2.7 -c -m dosf90 dos.f90
cp dosf90.so ../../ # copy to the main directory
