XXX -c -m dosf90 dos.f90
cp dosf90.so ../../ # copy to the main directory
