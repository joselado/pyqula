import numpy as np

def get_lead_dos(HT,**kwargs):
    """Compute the surface DOS of the lead"""

