densedimension = 10000 # maximum allowed dimension for dense matrices
