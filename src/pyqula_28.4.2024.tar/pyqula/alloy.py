from .energeticstk import alloytk

Alloy = alloytk.Alloy
array2dict = alloytk.array2dict



