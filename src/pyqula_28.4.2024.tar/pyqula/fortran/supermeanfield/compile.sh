/usr/bin/f2py3 -c -m supermeanfieldf90 supermeanfield.f90
