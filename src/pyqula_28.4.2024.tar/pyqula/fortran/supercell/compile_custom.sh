f2py2.7 -c -m supercellf90 supercellf90.f90
cp supercellf90.so ../../ # copy to the main directory
