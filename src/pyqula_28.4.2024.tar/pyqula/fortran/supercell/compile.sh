XXX -c -m supercellf90 supercellf90.f90
cp supercellf90.so ../../ # copy to the main directory
