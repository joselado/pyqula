XXX -c -m clean_geometryf90 clean_geometryf90.f90
cp clean_geometryf90.so ../../ # copy to the main directory
