f2py -llapack -c -m dyson2d dyson2d.f90

