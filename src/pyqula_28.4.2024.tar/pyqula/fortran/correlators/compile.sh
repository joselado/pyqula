XXX -c -m correlatorsf90 correlatorsf90.f90
cp correlatorsf90.so ../../ # copy to the main directory
