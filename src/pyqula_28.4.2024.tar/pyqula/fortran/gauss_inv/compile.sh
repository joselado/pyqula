f2py -llapack -c -m gauss_inv gauss_inv.f90
# rename compiled version as gauss_inv.so
