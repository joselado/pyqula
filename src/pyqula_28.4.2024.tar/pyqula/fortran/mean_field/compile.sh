f2py2.7 -llapack -c -m mean_fieldf90 mean_fieldf90.f90
cp mean_fieldf90.so ../../ # copy to the main directory
