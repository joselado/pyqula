
from scipy.sparse import csc_matrix,bmat
sx = csc_matrix([[0.,1.],[1.,0.]])
sy = csc_matrix([[0.,-1j],[1j,0.]])
sz = csc_matrix([[1.,0.],[0.,-1.]])


